import { type NextRequest, NextResponse } from "next/server"
import { get } from "@vercel/blob"
import crypto from "crypto"

export async function GET(request: NextRequest, { params }: { params: { fileId: string } }) {
  try {
    const { fileId } = params
    const { searchParams } = new URL(request.url)
    const password = searchParams.get("password")

    // In a real app, you would fetch file metadata from your database
    // to check if the file exists, if it's expired, and if it requires a password

    // Mock password check for demonstration
    const isPasswordProtected = fileId === "1" // Just for demo
    const correctPasswordHash = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8" // sha256 of "password"

    if (isPasswordProtected) {
      if (!password) {
        return NextResponse.json({ error: "Password required" }, { status: 401 })
      }

      const passwordHash = crypto.createHash("sha256").update(password).digest("hex")

      if (passwordHash !== correctPasswordHash) {
        return NextResponse.json({ error: "Invalid password" }, { status: 401 })
      }
    }

    // In a real app, you would get the actual file path from your database
    const filePath = `uploads/${fileId}/filename.ext`

    // Get file from Vercel Blob
    const blob = await get(filePath)

    if (!blob) {
      return NextResponse.json({ error: "File not found" }, { status: 404 })
    }

    // Log download for analytics (in a real app)

    // Redirect to the file URL
    return NextResponse.redirect(blob.url)
  } catch (error) {
    console.error("Error downloading file:", error)
    return NextResponse.json({ error: "Failed to download file" }, { status: 500 })
  }
}

