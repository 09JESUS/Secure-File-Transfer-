"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import FileUploadForm from "@/components/file-upload-form"
import FilesList from "@/components/files-list"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/lib/auth-context"
import { Shield, Upload, FileText } from "lucide-react"

export default function ClientHomePage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  // If not logged in, redirect to login page
  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <div className="container mx-auto py-10 text-center">
        <Shield className="h-12 w-12 mx-auto text-cyber-primary animate-pulse" />
        <p className="mt-4">Authenticating...</p>
      </div>
    )
  }

  if (!user) {
    return null // Will redirect to login
  }

  return (
    <div className="container mx-auto py-6 sm:py-10 px-4">
      <div className="text-center mb-6 sm:mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2 flex items-center justify-center gap-2">
          <Shield className="h-5 w-5 sm:h-6 sm:w-6 text-cyber-primary" />
          <span>Secure File Transfer</span>
        </h1>
        <p className="text-muted-foreground max-w-md mx-auto text-sm sm:text-base">
          Transfer files with end-to-end encryption and advanced security features
        </p>
      </div>

      <Tabs defaultValue="upload" className="max-w-4xl mx-auto">
        <TabsList className="grid w-full grid-cols-2 cyber-border p-1 bg-muted/30">
          <TabsTrigger
            value="upload"
            className="data-[state=active]:bg-cyber-primary data-[state=active]:text-background flex items-center gap-1 sm:gap-2 text-sm"
          >
            <Upload className="h-3 w-3 sm:h-4 sm:w-4" />
            Upload Files
          </TabsTrigger>
          <TabsTrigger
            value="files"
            className="data-[state=active]:bg-cyber-primary data-[state=active]:text-background flex items-center gap-1 sm:gap-2 text-sm"
          >
            <FileText className="h-3 w-3 sm:h-4 sm:w-4" />
            My Files
          </TabsTrigger>
        </TabsList>
        <TabsContent value="upload" className="p-3 sm:p-4 border rounded-md mt-2 cyber-border">
          <FileUploadForm />
        </TabsContent>
        <TabsContent value="files" className="p-3 sm:p-4 border rounded-md mt-2 cyber-border">
          <FilesList />
        </TabsContent>
      </Tabs>
    </div>
  )
}

