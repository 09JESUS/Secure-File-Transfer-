import { Shield, Lock, Clock, Eye } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { MessageSquare } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container mx-auto py-10">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">About SecureTransfer</h1>
        <p className="text-muted-foreground mb-8">
          SecureTransfer is a secure file sharing platform designed to help you transfer sensitive files safely and
          efficiently.
        </p>

        <div className="grid gap-6 md:grid-cols-2 mb-10">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                End-to-End Encryption
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                All files are encrypted during transfer and storage, ensuring your data remains private and secure.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                Automatic Expiration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Set expiration dates for your shared files to ensure they're not accessible indefinitely.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Password Protection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Add an extra layer of security with password protection for your most sensitive files.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-primary" />
                Access Tracking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Monitor who views and downloads your files with detailed access logs.
              </p>
            </CardContent>
          </Card>
        </div>

        <h2 className="text-2xl font-bold mb-4">How It Works</h2>
        <ol className="space-y-4 mb-10">
          <li className="flex gap-4">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
              1
            </div>
            <div>
              <h3 className="font-medium">Upload your file</h3>
              <p className="text-sm text-muted-foreground">
                Select the file you want to share and upload it to our secure servers.
              </p>
            </div>
          </li>
          <li className="flex gap-4">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
              2
            </div>
            <div>
              <h3 className="font-medium">Configure security settings</h3>
              <p className="text-sm text-muted-foreground">
                Set an expiration date, add password protection, and specify recipients.
              </p>
            </div>
          </li>
          <li className="flex gap-4">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
              3
            </div>
            <div>
              <h3 className="font-medium">Share the secure link</h3>
              <p className="text-sm text-muted-foreground">
                Send the generated link to your recipients via email or messaging apps.
              </p>
            </div>
          </li>
          <li className="flex gap-4">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
              4
            </div>
            <div>
              <h3 className="font-medium">Track access</h3>
              <p className="text-sm text-muted-foreground">
                Monitor who views and downloads your files with detailed access logs.
              </p>
            </div>
          </li>
        </ol>

        <div className="bg-muted p-6 rounded-lg">
          <h2 className="text-xl font-bold mb-2">Our Commitment to Security</h2>
          <p className="text-sm text-muted-foreground mb-4">
            At SecureTransfer, we prioritize the security and privacy of your data. Our platform is built with
            industry-leading security practices:
          </p>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <Shield className="h-4 w-4 mt-0.5 text-primary" />
              <span>AES-256 encryption for all stored files</span>
            </li>
            <li className="flex items-start gap-2">
              <Shield className="h-4 w-4 mt-0.5 text-primary" />
              <span>TLS/SSL encryption for all data in transit</span>
            </li>
            <li className="flex items-start gap-2">
              <Shield className="h-4 w-4 mt-0.5 text-primary" />
              <span>Automatic file deletion after expiration</span>
            </li>
            <li className="flex items-start gap-2">
              <Shield className="h-4 w-4 mt-0.5 text-primary" />
              <span>No storage of file passwords in plaintext</span>
            </li>
            <li className="flex items-start gap-2">
              <Shield className="h-4 w-4 mt-0.5 text-primary" />
              <span>Regular security audits and updates</span>
            </li>
          </ul>
        </div>
        <div className="mt-8 text-center">
          <Button
            asChild
            className="bg-cyber-primary text-background hover:bg-cyber-primary/90 relative overflow-hidden group"
          >
            <Link href="/contact" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              <span className="relative z-10">Contact Us</span>
              <span className="absolute inset-0 bg-gradient-to-r from-cyber-primary via-cyber-secondary to-cyber-primary bg-[length:200%_100%] animate-[gradient_3s_ease_infinite] opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

