"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { File, Download, Lock, Eye, Clock, Shield, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { getFileById, updateFileMetadata } from "@/lib/storage-utils"
import { useToast } from "@/hooks/use-toast"

interface SharePageProps {
  params: {
    fileId: string
  }
}

export default function SharePage({ params }: SharePageProps) {
  const { fileId } = params
  const router = useRouter()
  const { toast } = useToast()
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isDownloading, setIsDownloading] = useState(false)
  const [file, setFile] = useState<any>(null)

  useEffect(() => {
    const loadFile = async () => {
      try {
        const fileData = await getFileById(fileId)

        if (!fileData) {
          setError("File not found or has expired")
          return
        }

        // Check if file has expired
        const expiryDate = new Date(fileData.expiresAt)
        if (expiryDate < new Date()) {
          setError("This file has expired and is no longer available")
          return
        }

        setFile(fileData)

        // Update view count
        await updateFileMetadata(fileId, {
          views: fileData.views + 1,
        })
      } catch (error) {
        console.error("Error loading file:", error)
        setError("Failed to load file information")
      } finally {
        setIsLoading(false)
      }
    }

    loadFile()
  }, [fileId])

  const handleDownload = async () => {
    try {
      if (!file) return

      setIsDownloading(true)
      setError(null)

      // Check password if required
      if (file.isPasswordProtected) {
        if (!password) {
          setError("Please enter the password to download this file")
          setIsDownloading(false)
          return
        }

        if (password !== file.password) {
          setError("Invalid password. Please try again.")
          setIsDownloading(false)
          return
        }
      }

      // Update download count
      await updateFileMetadata(fileId, {
        downloads: file.downloads + 1,
      })

      // Create a download link
      const link = document.createElement("a")
      link.href = file.data
      link.download = file.name
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "Success",
        description: "File download started",
      })
    } catch (error) {
      console.error("Error downloading file:", error)
      setError("Failed to download file. Please try again.")
    } finally {
      setIsDownloading(false)
    }
  }

  const formatDate = (date: Date | string) => {
    const dateObj = typeof date === "string" ? new Date(date) : date
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(dateObj)
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-10 text-center">
        <Shield className="h-12 w-12 mx-auto text-cyber-primary animate-pulse" />
        <p className="mt-4">Loading file information...</p>
      </div>
    )
  }

  if (error && !file) {
    return (
      <div className="container mx-auto py-10">
        <div className="max-w-md mx-auto">
          <Alert variant="destructive" className="mb-4 border-cyber-alert bg-cyber-alert/10">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
          <div className="text-center mt-4">
            <Button variant="outline" onClick={() => router.push("/")}>
              Return to Home
            </Button>
          </div>
        </div>
      </div>
    )
  }

  if (!file) return null

  return (
    <div className="container mx-auto py-10">
      <div className="max-w-md mx-auto">
        <Card className="cyber-border max-w-[90vw] sm:max-w-md mx-auto">
          <CardHeader>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <File className="h-12 w-12 text-cyber-primary" />
              <div className="text-center sm:text-left">
                <CardTitle className="break-all">{file.name}</CardTitle>
                <CardDescription>{file.size.toFixed(1)} MB • Shared securely</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {file.message && <div className="mb-4 p-3 bg-muted rounded-md text-sm">{file.message}</div>}

            <div className="flex flex-wrap justify-center sm:justify-start items-center gap-4 text-sm text-muted-foreground mb-4">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4 text-cyber-primary" />
                <span>Expires {formatDate(file.expiresAt)}</span>
              </div>
              <div className="flex items-center gap-1">
                <Eye className="h-4 w-4 text-cyber-accent" />
                <span>{file.views} views</span>
              </div>
            </div>

            {file.isPasswordProtected && (
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-cyber-primary" />
                  <Label htmlFor="password">This file is password protected</Label>
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter password to download"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-background border-muted focus:border-cyber-primary focus:ring-cyber-primary/20"
                />
                {error && <p className="text-sm text-cyber-alert">{error}</p>}
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button
              className="w-full gap-2 bg-cyber-primary text-background hover:bg-cyber-primary/90"
              onClick={handleDownload}
              disabled={(file.isPasswordProtected && !password) || isDownloading}
            >
              <Download className="h-4 w-4" />
              {isDownloading ? "Processing..." : "Download File"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

