import type { Metadata } from "next"
import ContactForm from "@/components/contact-form"
import { Shield, Mail, MessageSquare } from "lucide-react"

export const metadata: Metadata = {
  title: "Contact Us | SecureTransfer",
  description: "Get in touch with our team for support or inquiries",
}

export default function ContactPage() {
  return (
    <div className="container mx-auto py-6 sm:py-10 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-6 sm:mb-8">
          <div className="flex justify-center mb-3 sm:mb-4">
            <div className="rounded-full bg-cyber-primary/10 p-3 sm:p-4">
              <MessageSquare className="h-8 w-8 sm:h-10 sm:w-10 text-cyber-primary animate-pulse-glow" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold mb-2">Contact Us</h1>
          <p className="text-muted-foreground max-w-md mx-auto text-sm sm:text-base">
            Have questions or need assistance? Our team is here to help.
          </p>
        </div>

        <div className="grid gap-6 sm:gap-8 md:grid-cols-2">
          <div className="space-y-6">
            <div className="cyber-border p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Shield className="h-5 w-5 text-cyber-primary" />
                Security Inquiries
              </h2>
              <p className="text-muted-foreground mb-4">
                For questions about our security practices, encryption methods, or data protection policies.
              </p>
              <div className="flex items-center gap-2 text-cyber-primary">
                <Mail className="h-4 w-4" />
                <span>security@securetransfer.app</span>
              </div>
            </div>

            <div className="cyber-border p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Mail className="h-5 w-5 text-cyber-secondary" />
                General Support
              </h2>
              <p className="text-muted-foreground mb-4">
                For general questions, account issues, or help with using our platform.
              </p>
              <div className="flex items-center gap-2 text-cyber-secondary">
                <Mail className="h-4 w-4" />
                <span>support@securetransfer.app</span>
              </div>
            </div>

            <div className="cyber-border p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-cyber-accent" />
                Business Inquiries
              </h2>
              <p className="text-muted-foreground mb-4">
                For partnership opportunities, enterprise plans, or business-related questions.
              </p>
              <div className="flex items-center gap-2 text-cyber-accent">
                <Mail className="h-4 w-4" />
                <span>business@securetransfer.app</span>
              </div>
            </div>
          </div>

          <div>
            <ContactForm />
          </div>
        </div>
      </div>
    </div>
  )
}

