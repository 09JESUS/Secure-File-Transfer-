"use client"

import { useState } from "react"
import { User, Mail, Shield } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/lib/auth-context"
import AuthRequired from "@/components/auth-required"

export default function ProfilePage() {
  const { user } = useAuth()
  const [name, setName] = useState(user?.name || "")
  const [email, setEmail] = useState(user?.email || "")
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    setIsSaving(true)
    try {
      // In a real app, you would call your API to update the user profile
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Update the user object with the new values
      const updatedUser = {
        ...user,
        name,
        email,
      }

      // Store the updated user in localStorage (in a real app, this would be handled by your auth system)
      if (user) {
        localStorage.setItem("user", JSON.stringify(updatedUser))
      }

      setIsEditing(false)

      // Show a success message or notification
      alert("Profile updated successfully!")
    } catch (error) {
      console.error("Failed to update profile:", error)
      alert("Failed to update profile. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <AuthRequired>
      <div className="container mx-auto py-10">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <div className="flex justify-center mb-4">
                <div className="rounded-full bg-primary/10 p-4">
                  <User className="h-8 w-8 text-primary" />
                </div>
              </div>
              <CardTitle className="text-2xl text-center">Your Profile</CardTitle>
              <CardDescription className="text-center">Manage your account information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                {isEditing ? (
                  <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
                ) : (
                  <div className="flex items-center gap-2 p-2 border rounded-md">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span>{user?.name || "Not set"}</span>
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                {isEditing ? (
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                ) : (
                  <div className="flex items-center gap-2 p-2 border rounded-md">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>{user?.email}</span>
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>Account Security</Label>
                <div className="flex items-center gap-2 p-2 border rounded-md">
                  <Shield className="h-4 w-4 text-muted-foreground" />
                  <span>Password protected</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              {isEditing ? (
                <>
                  <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSaving}>
                    Cancel
                  </Button>
                  <Button onClick={handleSave} disabled={isSaving}>
                    {isSaving ? "Saving..." : "Save changes"}
                  </Button>
                </>
              ) : (
                <Button className="w-full" onClick={() => setIsEditing(true)}>
                  Edit Profile
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>
      </div>
    </AuthRequired>
  )
}

