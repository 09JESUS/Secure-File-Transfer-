import type { Metadata } from "next"
import ClientHomePage from "./ClientHomePage"

export const metadata: Metadata = {
  title: "Secure File Transfer",
  description: "Securely transfer files with end-to-end encryption",
}

export default function HomePage() {
  return <ClientHomePage />
}

