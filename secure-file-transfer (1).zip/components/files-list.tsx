"use client"

import { useState, useEffect } from "react"
import { File, Download, Trash2, Copy, Clock, Eye, Lock, Mail, Shield, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/lib/auth-context"
import { getUserFiles, deleteFileById, updateFileMetadata, type StoredFile } from "@/lib/storage-utils"
import { useToast } from "@/hooks/use-toast"

export default function FilesList() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [files, setFiles] = useState<StoredFile[]>([])
  const [shareUrl, setShareUrl] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)
  const [fileToDelete, setFileToDelete] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [copySuccess, setCopySuccess] = useState<string | null>(null)

  // Load files from storage
  const loadFiles = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const userFiles = await getUserFiles(user.id)
      // Sort files by upload date (newest first)
      userFiles.sort((a, b) => {
        return new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
      })
      setFiles(userFiles)
    } catch (error) {
      console.error("Error loading files:", error)
      toast({
        title: "Error",
        description: "Failed to load your files. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (user) {
      loadFiles()
    }
  }, [user])

  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url)
    setCopySuccess("Link copied to clipboard!")
    setTimeout(() => setCopySuccess(null), 2000)
  }

  const handleDelete = async (id: string) => {
    try {
      setIsDeleting(true)
      const success = await deleteFileById(id)

      if (success) {
        setFiles(files.filter((file) => file.id !== id))
        toast({
          title: "Success",
          description: "File deleted successfully",
        })
      } else {
        throw new Error("Failed to delete file")
      }
    } catch (error) {
      console.error("Failed to delete file:", error)
      toast({
        title: "Error",
        description: "Failed to delete file. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
      setFileToDelete(null)
    }
  }

  const handleDownload = async (file: StoredFile) => {
    try {
      // Update download count
      await updateFileMetadata(file.id, {
        downloads: file.downloads + 1,
      })

      // Create a download link
      const link = document.createElement("a")
      link.href = file.data as string
      link.download = file.name
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      // Refresh the file list
      loadFiles()

      toast({
        title: "Success",
        description: "File download started",
      })
    } catch (error) {
      console.error("Failed to download file:", error)
      toast({
        title: "Error",
        description: "Failed to download file. Please try again.",
        variant: "destructive",
      })
    }
  }

  const formatDate = (date: Date | string) => {
    const dateObj = typeof date === "string" ? new Date(date) : date
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(dateObj)
  }

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split(".").pop()?.toLowerCase()

    switch (extension) {
      case "pdf":
        return <FileText className="h-10 w-10 text-cyber-alert" />
      case "doc":
      case "docx":
        return <FileText className="h-10 w-10 text-cyber-secondary" />
      case "xls":
      case "xlsx":
        return <FileText className="h-10 w-10 text-cyber-matrix" />
      case "ppt":
      case "pptx":
        return <FileText className="h-10 w-10 text-cyber-accent" />
      case "jpg":
      case "jpeg":
      case "png":
      case "gif":
        return <FileText className="h-10 w-10 text-cyber-primary" />
      default:
        return <File className="h-10 w-10 text-cyber-primary" />
    }
  }

  if (isLoading) {
    return (
      <div className="text-center py-10">
        <Shield className="h-12 w-12 mx-auto text-cyber-primary animate-pulse" />
        <p className="mt-4">Loading your files...</p>
      </div>
    )
  }

  if (files.length === 0) {
    return (
      <div className="text-center py-10">
        <File className="h-12 w-12 mx-auto text-muted-foreground" />
        <h3 className="mt-4 text-lg font-medium">No files uploaded yet</h3>
        <p className="mt-1 text-sm text-muted-foreground">Upload a file to get started</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {files.map((file) => (
        <Card
          key={file.id}
          className="cyber-border overflow-hidden transition-all duration-300 hover:shadow-md hover:shadow-cyber-primary/10"
        >
          <CardHeader className="pb-2">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-2">
              <div className="flex items-start gap-3">
                {getFileIcon(file.name)}
                <div>
                  <CardTitle className="text-base">{file.name}</CardTitle>
                  <CardDescription>
                    {file.size.toFixed(1)} MB • Uploaded {formatDate(file.uploadedAt)}
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-1 mt-2 sm:mt-0">
                {file.isPasswordProtected && (
                  <Badge variant="outline" className="gap-1 border-cyber-primary text-cyber-primary">
                    <Lock className="h-3 w-3" />
                    Protected
                  </Badge>
                )}
                {file.recipient && (
                  <Badge variant="outline" className="gap-1 border-cyber-secondary text-cyber-secondary">
                    <Mail className="h-3 w-3" />
                    Shared
                  </Badge>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="pb-2">
            <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4 text-cyber-primary" />
                <span>Expires {formatDate(file.expiresAt)}</span>
              </div>
              <div className="flex items-center gap-1">
                <Download className="h-4 w-4 text-cyber-secondary" />
                <span>{file.downloads} downloads</span>
              </div>
              <div className="flex items-center gap-1">
                <Eye className="h-4 w-4 text-cyber-accent" />
                <span>{file.views} views</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="flex flex-col sm:flex-row sm:justify-between gap-2">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDownload(file)}
                  className="border-cyber-secondary text-cyber-secondary hover:bg-cyber-secondary/10 hover:text-cyber-secondary"
                >
                  <Download className="h-4 w-4 mr-1" />
                  Download
                </Button>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-cyber-primary text-cyber-primary hover:bg-cyber-primary/10 hover:text-cyber-primary"
                      onClick={() => setShareUrl(`${window.location.origin}/share/${file.id}`)}
                    >
                      <Copy className="h-4 w-4 mr-1" />
                      Share
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="cyber-border bg-card max-w-[90vw] sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle className="text-foreground flex items-center gap-2">
                        <Shield className="h-5 w-5 text-cyber-primary" />
                        Share File Securely
                      </DialogTitle>
                      <DialogDescription>Copy the secure link below to share this file</DialogDescription>
                    </DialogHeader>
                    <div className="flex items-center gap-2 mt-4">
                      <Input
                        value={shareUrl}
                        readOnly
                        className="bg-background border-muted focus:border-cyber-primary"
                      />
                      <Button
                        variant="outline"
                        onClick={() => handleCopyLink(shareUrl)}
                        className="border-cyber-primary text-cyber-primary hover:bg-cyber-primary/10 shrink-0"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    {copySuccess && <p className="text-sm text-cyber-primary mt-2 animate-fade-in">{copySuccess}</p>}
                    {file.isPasswordProtected && (
                      <div className="mt-4">
                        <Label htmlFor="password" className="flex items-center gap-2">
                          <Lock className="h-4 w-4 text-cyber-primary" />
                          Password
                        </Label>
                        <div className="flex items-center gap-2 mt-1">
                          <Input
                            id="password"
                            type="text"
                            value={file.password || "••••••••"}
                            readOnly
                            className="bg-background border-muted"
                          />
                          <Button
                            variant="outline"
                            onClick={() => handleCopyLink(file.password || "")}
                            className="border-cyber-primary text-cyber-primary hover:bg-cyber-primary/10 shrink-0"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    )}
                    <DialogFooter className="mt-4">
                      <Button
                        variant="outline"
                        onClick={() => setShareUrl("")}
                        className="border-muted text-muted-foreground hover:bg-background"
                      >
                        Close
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>

              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-cyber-alert text-cyber-alert hover:bg-cyber-alert/10 hover:text-cyber-alert mt-2 sm:mt-0"
                    onClick={() => setFileToDelete(file.id)}
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </DialogTrigger>
                <DialogContent className="cyber-border bg-card max-w-[90vw] sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-foreground">Delete File</DialogTitle>
                    <DialogDescription>
                      Are you sure you want to delete this file? This action cannot be undone.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter className="mt-4 flex-col sm:flex-row gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setFileToDelete(null)}
                      className="border-muted text-muted-foreground hover:bg-background w-full sm:w-auto"
                    >
                      Cancel
                    </Button>
                    <Button
                      variant="destructive"
                      onClick={() => handleDelete(file.id)}
                      disabled={isDeleting}
                      className="bg-cyber-alert text-white hover:bg-cyber-alert/90 w-full sm:w-auto"
                    >
                      {isDeleting ? "Deleting..." : "Delete"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

