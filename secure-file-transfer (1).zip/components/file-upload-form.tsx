"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Upload, X, Check, AlertCircle, Shield, Lock, FileText, File } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useAuth } from "@/lib/auth-context"
import { Progress } from "@/components/ui/progress"
import { fileToStoredFile, storeFile } from "@/lib/storage-utils"

export default function FileUploadForm() {
  const router = useRouter()
  const { user } = useAuth()
  const [file, setFile] = useState<File | null>(null)
  const [recipient, setRecipient] = useState("")
  const [message, setMessage] = useState("")
  const [expiryDays, setExpiryDays] = useState("7")
  const [passwordProtect, setPasswordProtect] = useState(false)
  const [password, setPassword] = useState("")
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isScanning, setIsScanning] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Animation for upload progress
  useEffect(() => {
    if (isUploading) {
      const interval = setInterval(() => {
        setUploadProgress((prev) => {
          const newProgress = prev + Math.random() * 15
          return newProgress >= 100 ? 100 : newProgress
        })
      }, 300)

      return () => clearInterval(interval)
    } else {
      setUploadProgress(0)
    }
  }, [isUploading])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
      setError(null)

      // Start scanning animation
      setIsScanning(true)
      setTimeout(() => {
        setIsScanning(false)
      }, 2000)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!file) {
      setError("Please select a file to upload")
      return
    }

    if (recipient && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient)) {
      setError("Please enter a valid email address")
      return
    }

    if (passwordProtect && !password) {
      setError("Please enter a password for the file")
      return
    }

    try {
      setIsUploading(true)
      setError(null)

      // Convert the File to a StoredFile
      const storedFile = await fileToStoredFile(file, user?.id || "anonymous", {
        expiryDays: Number.parseInt(expiryDays),
        isPasswordProtected: passwordProtect,
        password,
        recipient,
        message,
      })

      // Store the file in IndexedDB
      await storeFile(storedFile)

      // Simulate network delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setSuccess(true)
      setFile(null)
      setRecipient("")
      setMessage("")
      setExpiryDays("7")
      setPasswordProtect(false)
      setPassword("")

      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }

      // Refresh the files list
      router.refresh()

      // Reset success message after 5 seconds
      setTimeout(() => {
        setSuccess(false)
      }, 5000)
    } catch (err) {
      setError("Failed to upload file. Please try again.")
      console.error(err)
    } finally {
      setIsUploading(false)
      setUploadProgress(0)
    }
  }

  const getFileIcon = (fileName: string) => {
    if (!fileName) return <File className="h-10 w-10 text-cyber-primary" />

    const extension = fileName.split(".").pop()?.toLowerCase()

    switch (extension) {
      case "pdf":
        return <FileText className="h-10 w-10 text-cyber-alert" />
      case "doc":
      case "docx":
        return <FileText className="h-10 w-10 text-cyber-secondary" />
      case "xls":
      case "xlsx":
        return <FileText className="h-10 w-10 text-cyber-matrix" />
      case "ppt":
      case "pptx":
        return <FileText className="h-10 w-10 text-cyber-accent" />
      case "jpg":
      case "jpeg":
      case "png":
      case "gif":
        return <FileText className="h-10 w-10 text-cyber-primary" />
      default:
        return <File className="h-10 w-10 text-cyber-primary" />
    }
  }

  return (
    <div>
      {error && (
        <Alert variant="destructive" className="mb-4 border-cyber-alert bg-cyber-alert/10">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-4 border-cyber-matrix bg-cyber-matrix/10">
          <Check className="h-4 w-4 text-cyber-matrix" />
          <AlertTitle className="text-cyber-matrix">Success</AlertTitle>
          <AlertDescription>File uploaded successfully!</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="file" className="text-foreground/90">
            File
          </Label>
          <div className="flex flex-col sm:flex-row items-center gap-2">
            <Input id="file" type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
            <div className="grid w-full gap-2">
              <Label
                htmlFor="file"
                className={`flex h-32 w-full cursor-pointer flex-col items-center justify-center rounded-md border border-dashed 
                  ${file ? "border-cyber-primary" : "border-muted-foreground/25"} 
                  ${isScanning ? "cyber-scanner" : ""} 
                  px-4 py-5 text-center transition-all duration-300 hover:border-cyber-primary hover:bg-cyber-primary/5`}
              >
                {file ? (
                  <div className="flex flex-col items-center animate-fade-in">
                    {getFileIcon(file.name)}
                    <div className="mt-2 text-sm text-foreground break-all max-w-full px-2">{file.name}</div>
                    <div className="mt-1 text-xs text-muted-foreground">{(file.size / 1024 / 1024).toFixed(2)} MB</div>
                    {isScanning && (
                      <div className="mt-2 text-xs text-cyber-primary animate-pulse">Scanning file for viruses...</div>
                    )}
                  </div>
                ) : (
                  <>
                    <Upload className="h-6 w-6 text-muted-foreground" />
                    <div className="mt-2 text-sm text-muted-foreground">Drag and drop or click to upload</div>
                  </>
                )}
              </Label>
            </div>
            {file && (
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setFile(null)}
                className="border-cyber-alert text-cyber-alert hover:bg-cyber-alert/10 hover:text-cyber-alert mt-2 sm:mt-0"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="recipient" className="text-foreground/90">
            Recipient Email (optional)
          </Label>
          <Input
            id="recipient"
            type="email"
            placeholder="recipient@example.com"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            className="bg-background border-muted focus:border-cyber-primary focus:ring-cyber-primary/20"
          />
          <p className="text-xs text-muted-foreground">Leave blank to generate a shareable link</p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="message" className="text-foreground/90">
            Message (optional)
          </Label>
          <Textarea
            id="message"
            placeholder="Add a message for the recipient"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="bg-background border-muted focus:border-cyber-primary focus:ring-cyber-primary/20"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="expiry" className="text-foreground/90">
            Link Expiry
          </Label>
          <select
            id="expiry"
            value={expiryDays}
            onChange={(e) => setExpiryDays(e.target.value)}
            className="flex h-10 w-full rounded-md border border-muted bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyber-primary/20 focus-visible:border-cyber-primary disabled:cursor-not-allowed disabled:opacity-50"
          >
            <option value="1">1 day</option>
            <option value="3">3 days</option>
            <option value="7">7 days</option>
            <option value="14">14 days</option>
            <option value="30">30 days</option>
          </select>
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="password-protect"
            checked={passwordProtect}
            onCheckedChange={setPasswordProtect}
            className="data-[state=checked]:bg-cyber-primary data-[state=checked]:text-background"
          />
          <Label htmlFor="password-protect" className="text-foreground/90 flex items-center gap-1">
            <Lock className="h-3.5 w-3.5 text-cyber-primary" />
            Password protect
          </Label>
        </div>

        {passwordProtect && (
          <div className="space-y-2 animate-fade-in">
            <Label htmlFor="password" className="text-foreground/90">
              Password
            </Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter a secure password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-background border-muted focus:border-cyber-primary focus:ring-cyber-primary/20"
            />
          </div>
        )}

        {isUploading && (
          <div className="space-y-2 animate-fade-in">
            <div className="flex justify-between text-xs">
              <span>Uploading...</span>
              <span>{Math.round(uploadProgress)}%</span>
            </div>
            <Progress value={uploadProgress} className="h-2 bg-muted" indicatorClassName="bg-cyber-primary" />
          </div>
        )}

        <Button
          type="submit"
          className="w-full bg-cyber-primary text-background hover:bg-cyber-primary/90 relative overflow-hidden group"
          disabled={isUploading}
        >
          <span className="relative z-10 flex items-center gap-2">
            {isUploading ? (
              <>
                <Shield className="h-4 w-4 animate-pulse" />
                Encrypting & Uploading...
              </>
            ) : (
              <>
                <Shield className="h-4 w-4" />
                Secure Upload
              </>
            )}
          </span>
          <span className="absolute inset-0 bg-gradient-to-r from-cyber-primary via-cyber-secondary to-cyber-primary bg-[length:200%_100%] animate-[gradient_3s_ease_infinite] opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
        </Button>
      </form>
    </div>
  )
}

