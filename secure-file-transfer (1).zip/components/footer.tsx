import Link from "next/link"
import { Shield } from "lucide-react"

export default function Footer() {
  return (
    <footer className="border-t border-border/40 py-4 sm:py-6 md:py-0">
      <div className="container mx-auto flex flex-col items-center justify-between gap-3 md:h-16 md:flex-row px-4">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-cyber-primary" />
          <p className="text-xs sm:text-sm text-muted-foreground">
            © 2025 Designed and Developed by Forget Nukeri (F-tee)
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-3 sm:gap-4">
          <Link
            href="/privacy"
            className="text-xs sm:text-sm text-muted-foreground hover:text-cyber-primary transition-colors"
          >
            Privacy
          </Link>
          <Link
            href="/terms"
            className="text-xs sm:text-sm text-muted-foreground hover:text-cyber-primary transition-colors"
          >
            Terms
          </Link>
          <Link
            href="/security"
            className="text-xs sm:text-sm text-muted-foreground hover:text-cyber-primary transition-colors"
          >
            Security
          </Link>
          <Link
            href="/contact"
            className="text-xs sm:text-sm text-muted-foreground hover:text-cyber-primary transition-colors"
          >
            Contact
          </Link>
        </div>
      </div>
    </footer>
  )
}

