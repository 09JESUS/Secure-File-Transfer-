"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "./mode-toggle"
import { Shield, Lock, LogOut, User } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function Header() {
  const { user, logout } = useAuth()

  return (
    <header className="border-b border-border/40 backdrop-blur-sm bg-background/95 sticky top-0 z-50">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2 group">
          <Shield className="h-6 w-6 text-cyber-primary group-hover:animate-pulse transition-all duration-300" />
          <span className="font-bold text-foreground">
            <span className="text-cyber-primary">Secure</span>Transfer
          </span>
        </Link>

        <div className="flex items-center gap-2 sm:gap-4">
          <div className="hidden sm:flex">
            <Button
              variant="ghost"
              size="sm"
              asChild
              className="text-foreground/80 hover:text-cyber-primary hover:bg-cyber-primary/5"
            >
              <Link href="/about">About</Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              asChild
              className="text-foreground/80 hover:text-cyber-primary hover:bg-cyber-primary/5"
            >
              <Link href="/contact">Contact</Link>
            </Button>
          </div>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1 sm:gap-2 border-cyber-primary text-cyber-primary hover:bg-cyber-primary/10"
                >
                  <User className="h-4 w-4" />
                  <span className="hidden sm:inline">{user.name || user.email}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="cyber-border bg-card">
                <DropdownMenuLabel className="text-foreground">My Account</DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-border/40" />
                <DropdownMenuItem
                  asChild
                  className="text-foreground/80 focus:text-cyber-primary focus:bg-cyber-primary/5"
                >
                  <Link href="/profile">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem
                  asChild
                  className="text-foreground/80 focus:text-cyber-primary focus:bg-cyber-primary/5"
                >
                  <Link href="/settings">Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-border/40" />
                <DropdownMenuItem
                  asChild
                  className="text-foreground/80 focus:text-cyber-primary focus:bg-cyber-primary/5 sm:hidden"
                >
                  <Link href="/about">About</Link>
                </DropdownMenuItem>
                <DropdownMenuItem
                  asChild
                  className="text-foreground/80 focus:text-cyber-primary focus:bg-cyber-primary/5 sm:hidden"
                >
                  <Link href="/contact">Contact</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-border/40 sm:hidden" />
                <DropdownMenuItem
                  onClick={() => logout()}
                  className="text-cyber-alert focus:text-cyber-alert focus:bg-cyber-alert/5"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="gap-1 sm:gap-2 border-cyber-primary text-cyber-primary hover:bg-cyber-primary/10"
              asChild
            >
              <Link href="/login">
                <Lock className="h-4 w-4" />
                <span className="hidden sm:inline">Login</span>
              </Link>
            </Button>
          )}

          <ModeToggle />
        </div>
      </div>
    </header>
  )
}

