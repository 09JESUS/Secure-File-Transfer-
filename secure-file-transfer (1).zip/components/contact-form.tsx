"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Send, AlertCircle, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { submitContactForm } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"

export default function ContactForm() {
  const router = useRouter()
  const { toast } = useToast()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [subject, setSubject] = useState("")
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!name || !email || !subject || !message) {
      setError("Please fill in all fields")
      return
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Please enter a valid email address")
      return
    }

    try {
      setIsSubmitting(true)

      // Call the server action to submit the form and send email
      await submitContactForm({
        name,
        email,
        subject,
        message,
      })

      // Show success message
      setSuccess(true)
      toast({
        title: "Message Sent",
        description: "Your message has been sent successfully. We'll get back to you soon.",
        variant: "success",
      })

      // Reset form
      setName("")
      setEmail("")
      setSubject("")
      setMessage("")

      // Reset success message after 5 seconds
      setTimeout(() => {
        setSuccess(false)
      }, 5000)
    } catch (err) {
      setError("Failed to submit form. Please try again.")
      toast({
        title: "Error",
        description: "There was a problem sending your message. Please try again later.",
        variant: "destructive",
      })
      console.error(err)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="cyber-border overflow-hidden">
      <CardHeader>
        <CardTitle>Send us a message</CardTitle>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4 border-cyber-alert bg-cyber-alert/10">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mb-4 border-cyber-matrix bg-cyber-matrix/10">
            <Check className="h-4 w-4 text-cyber-matrix" />
            <AlertTitle className="text-cyber-matrix">Success</AlertTitle>
            <AlertDescription>Your message has been sent! We'll get back to you soon.</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-foreground/90">
              Name
            </Label>
            <Input
              id="name"
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-background border-muted focus:border-cyber-primary focus:ring-cyber-primary/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-foreground/90">
              Email
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-background border-muted focus:border-cyber-primary focus:ring-cyber-primary/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject" className="text-foreground/90">
              Subject
            </Label>
            <Input
              id="subject"
              placeholder="What's this about?"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="bg-background border-muted focus:border-cyber-primary focus:ring-cyber-primary/20"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message" className="text-foreground/90">
              Message
            </Label>
            <Textarea
              id="message"
              placeholder="Your message..."
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="bg-background border-muted focus:border-cyber-primary focus:ring-cyber-primary/20"
            />
          </div>
        </form>
      </CardContent>
      <CardFooter>
        <Button
          onClick={handleSubmit}
          className="w-full bg-cyber-primary text-background hover:bg-cyber-primary/90 relative overflow-hidden group"
          disabled={isSubmitting}
        >
          <span className="relative z-10 flex items-center gap-2">
            {isSubmitting ? (
              "Sending..."
            ) : (
              <>
                <Send className="h-4 w-4" />
                Send Message
              </>
            )}
          </span>
          <span className="absolute inset-0 bg-gradient-to-r from-cyber-primary via-cyber-secondary to-cyber-primary bg-[length:200%_100%] animate-[gradient_3s_ease_infinite] opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
        </Button>
      </CardFooter>
    </Card>
  )
}

