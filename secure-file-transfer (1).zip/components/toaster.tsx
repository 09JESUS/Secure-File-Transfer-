"use client"
import { useToast } from "@/hooks/use-toast"
import { Toast } from "@/components/ui/toast"

export function Toaster() {
  const { toasts, dismissToast } = useToast()

  return (
    <div className="fixed bottom-0 right-0 z-50 p-3 sm:p-4 space-y-2 max-w-[90vw] sm:max-w-md w-full">
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          variant={toast.variant}
          title={toast.title}
          description={toast.description}
          onClose={() => dismissToast(toast.id)}
        />
      ))}
    </div>
  )
}

