"use client"

import type React from "react"

import { useState } from "react"
import type { ToastProps } from "@/components/ui/toast"

type ToastType = ToastProps & {
  id: string
  title?: React.ReactNode
  description?: React.ReactNode
}

export function useToast() {
  const [toasts, setToasts] = useState<ToastType[]>([])

  const toast = ({
    title,
    description,
    variant = "default",
  }: {
    title: string
    description?: string
    variant?: "default" | "destructive" | "success"
  }) => {
    const id = Math.random().toString(36).substring(2, 9)
    const newToast = { id, title, description, variant }

    setToasts((prevToasts) => [...prevToasts, newToast])

    // Auto dismiss after 5 seconds
    setTimeout(() => {
      dismissToast(id)
    }, 5000)

    return id
  }

  const dismissToast = (id: string) => {
    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id))
  }

  return { toast, dismissToast, toasts }
}

