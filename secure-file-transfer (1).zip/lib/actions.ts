"use server"

import { revalidatePath } from "next/cache"
import crypto from "crypto"
import { cookies } from "next/headers"
import nodemailer from "nodemailer"

interface UploadFileParams {
  file: File
  userId?: string
  recipient?: string
  message?: string
  expiryDays: number
  passwordProtect: boolean
  password?: string
}

export async function uploadFile({
  file,
  userId,
  recipient,
  message,
  expiryDays,
  passwordProtect,
  password,
}: UploadFileParams) {
  try {
    // Generate a unique file ID
    const fileId = crypto.randomUUID()

    // Calculate expiry date
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + expiryDays)

    // In a real app, we would store the file in a database or cloud storage
    // For this demo, we'll store the file ID in a cookie so the client can handle it
    const fileData = {
      id: fileId,
      name: file.name,
      size: file.size / (1024 * 1024), // Convert to MB
      type: file.type,
      userId: userId || "anonymous",
      uploadedAt: new Date().toISOString(),
      expiresAt: expiresAt.toISOString(),
      isPasswordProtected: passwordProtect,
      password: passwordProtect ? password : undefined,
      recipient,
      message,
    }

    // Store file info in a cookie for the client to handle
    cookies().set("lastUploadedFile", JSON.stringify(fileData))

    // If password protection is enabled, hash the password
    let passwordHash = null
    if (passwordProtect && password) {
      passwordHash = crypto.createHash("sha256").update(password).digest("hex")
    }

    // If recipient is provided, send an email notification
    if (recipient) {
      // In a real app, you would send an email to the recipient
      console.log(`Email notification sent to ${recipient}`)
    }

    revalidatePath("/")

    return {
      success: true,
      fileId,
      fileData,
    }
  } catch (error) {
    console.error("Error uploading file:", error)
    throw new Error("Failed to upload file")
  }
}

export async function deleteFile(fileId: string, userId?: string) {
  try {
    // In a real app, you would delete the file from your database
    // For this demo, we'll just return success
    await new Promise((resolve) => setTimeout(resolve, 500))

    revalidatePath("/")

    return { success: true }
  } catch (error) {
    console.error("Error deleting file:", error)
    throw new Error("Failed to delete file")
  }
}

interface ContactFormData {
  name: string
  email: string
  subject: string
  message: string
}

export async function submitContactForm({ name, email, subject, message }: ContactFormData) {
  try {
    // Set up Nodemailer transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER, // Your email (must enable less secure apps or use app password)
        pass: process.env.EMAIL_PASS, // Your email password or app password
      },
    })

    // Email content
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: "nhlamuloftee@gmail.com",
      subject: `SecureTransfer Contact: ${subject}`,
      html: `
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Subject:</strong> ${subject}</p>
        <p><strong>Message:</strong></p>
        <p>${message.replace(/\n/g, "<br>")}</p>
        <hr>
        <p>This email was sent from the SecureTransfer contact form.</p>
      `,
    }

    // Send email
    await transporter.sendMail(mailOptions)

    console.log("Contact form submitted and email sent:", { name, email, subject })

    return {
      success: true,
    }
  } catch (error) {
    console.error("Error submitting contact form:", error)
    throw new Error("Failed to submit contact form")
  }
}

