// A utility for storing and retrieving files using IndexedDB
export interface StoredFile {
  id: string
  name: string
  size: number
  type: string
  data: ArrayBuffer | string // For actual file data or URL
  userId: string
  uploadedAt: Date
  expiresAt: Date
  isPasswordProtected: boolean
  password?: string
  recipient?: string | null
  message?: string | null
  downloads: number
  views: number
}

// Initialize the IndexedDB database
const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("SecureTransferDB", 1)

    request.onerror = (event) => {
      reject("Error opening database")
    }

    request.onsuccess = (event) => {
      resolve(request.result)
    }

    request.onupgradeneeded = (event) => {
      const db = request.result
      // Create an object store for files
      if (!db.objectStoreNames.contains("files")) {
        const store = db.createObjectStore("files", { keyPath: "id" })
        store.createIndex("userId", "userId", { unique: false })
        store.createIndex("uploadedAt", "uploadedAt", { unique: false })
      }
    }
  })
}

// Store a file in IndexedDB
export const storeFile = async (file: StoredFile): Promise<string> => {
  try {
    const db = await initDB()
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(["files"], "readwrite")
      const store = transaction.objectStore("files")
      const request = store.put(file)

      request.onsuccess = () => {
        resolve(file.id)
      }

      request.onerror = () => {
        reject("Error storing file")
      }
    })
  } catch (error) {
    console.error("Error in storeFile:", error)
    throw new Error("Failed to store file")
  }
}

// Get all files for a user
export const getUserFiles = async (userId: string): Promise<StoredFile[]> => {
  try {
    const db = await initDB()
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(["files"], "readonly")
      const store = transaction.objectStore("files")
      const index = store.index("userId")
      const request = index.getAll(userId)

      request.onsuccess = () => {
        resolve(request.result)
      }

      request.onerror = () => {
        reject("Error getting files")
      }
    })
  } catch (error) {
    console.error("Error in getUserFiles:", error)
    return []
  }
}

// Get a file by ID
export const getFileById = async (fileId: string): Promise<StoredFile | null> => {
  try {
    const db = await initDB()
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(["files"], "readonly")
      const store = transaction.objectStore("files")
      const request = store.get(fileId)

      request.onsuccess = () => {
        resolve(request.result || null)
      }

      request.onerror = () => {
        reject("Error getting file")
      }
    })
  } catch (error) {
    console.error("Error in getFileById:", error)
    return null
  }
}

// Delete a file by ID
export const deleteFileById = async (fileId: string): Promise<boolean> => {
  try {
    const db = await initDB()
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(["files"], "readwrite")
      const store = transaction.objectStore("files")
      const request = store.delete(fileId)

      request.onsuccess = () => {
        resolve(true)
      }

      request.onerror = () => {
        reject("Error deleting file")
      }
    })
  } catch (error) {
    console.error("Error in deleteFileById:", error)
    return false
  }
}

// Update file metadata
export const updateFileMetadata = async (fileId: string, updates: Partial<StoredFile>): Promise<boolean> => {
  try {
    const file = await getFileById(fileId)
    if (!file) return false

    const updatedFile = { ...file, ...updates }
    await storeFile(updatedFile)
    return true
  } catch (error) {
    console.error("Error in updateFileMetadata:", error)
    return false
  }
}

// Convert a File object to a StoredFile
export const fileToStoredFile = async (
  file: File,
  userId: string,
  options: {
    expiryDays: number
    isPasswordProtected: boolean
    password?: string
    recipient?: string
    message?: string
  },
): Promise<StoredFile> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onload = (event) => {
      if (!event.target?.result) {
        reject("Error reading file")
        return
      }

      const expiresAt = new Date()
      expiresAt.setDate(expiresAt.getDate() + options.expiryDays)

      const storedFile: StoredFile = {
        id: crypto.randomUUID(),
        name: file.name,
        size: file.size / (1024 * 1024), // Convert to MB
        type: file.type,
        data: event.target.result,
        userId,
        uploadedAt: new Date(),
        expiresAt,
        isPasswordProtected: options.isPasswordProtected,
        password: options.isPasswordProtected ? options.password : undefined,
        recipient: options.recipient || null,
        message: options.message || null,
        downloads: 0,
        views: 0,
      }

      resolve(storedFile)
    }

    reader.onerror = () => {
      reject("Error reading file")
    }

    reader.readAsDataURL(file)
  })
}

